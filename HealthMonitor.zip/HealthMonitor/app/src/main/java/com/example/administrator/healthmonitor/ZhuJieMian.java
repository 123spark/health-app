package com.example.administrator.healthmonitor;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ZhuJieMian extends AppCompatActivity {

    /*private Button ceshiButton, lishiButton, pingfenButton,
            shebeiButton, xinxiButton, backButton, editButton;*/


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.title_eidt, menu);
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zhu_jie_mian);


        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        /*ceshiButton=(Button)findViewById(R.id.button_ceshi);
        lishiButton=(Button)findViewById(R.id.button_lishi);
        pingfenButton=(Button)findViewById(R.id.button_pingfen);
        shebeiButton=(Button)findViewById(R.id.button_shebei);
        xinxiButton=(Button)findViewById(R.id.button_xinxi);*/

    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.item_qiehuan:
                //切换账号
                break;
            case R.id.item_shezhi:
                //切换账号
                break;
            case R.id.item_zhuxiao:
                Intent i=new Intent();
                i.setClass(ZhuJieMian.this,MainActivity.class);
                ZhuJieMian.this.startActivity(i);
                onStop();
                break;
        }
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return true;
    }

    /*protected void onStart(){
        super.onStart();
        ceshiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            //跳转到心率测试界面
            }
        });

        lishiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到历史数据界面
            }
        });

        pingfenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到健康评分界面
            }
        });

        shebeiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到设备管理界面
            }
        });

        xinxiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到个人信息界面
            }
        });
    }*/
}
