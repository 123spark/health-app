package com.example.administrator.healthmonitor;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Administrator on 2017/12/16.
 */

public class Fragment_zhaohui_1 extends Fragment {
    private String yanzhengma;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle saveInstanceState){
        View view=inflater.inflate(R.layout.fragment_zhaohui_1,container,false);

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Button button1 = (Button) getActivity().findViewById(R.id.button_queding_1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s="1234";
                EditText editText=(EditText)getActivity().findViewById(R.id.edit_yanzheng);
                yanzhengma=editText.getText().toString();
                if(yanzhengma.equals(s)){
                    getActivity().getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.fragment, new Fragment_zhaohui_2(), null)
                            .commit();
                }
                else{
                    Toast.makeText(getActivity(), "验证码错误", Toast.LENGTH_LONG).show();
                }
            }
        });

        Button button2 = (Button) getActivity().findViewById(R.id.button_yanzheng);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 Toast.makeText(getActivity(), "验证码已发送", Toast.LENGTH_LONG).show();
            }
        });

    }
}
